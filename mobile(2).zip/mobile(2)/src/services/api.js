
import { Platform } from 'react-native';

export const API = (process.env.EXPO_PUBLIC_API_URL || '').replace(/\/$/, '');
export const WEB = (process.env.EXPO_PUBLIC_WEB_URL || '').replace(/\/$/, '');

export async function request(path, token = null, options = {}) {
  const developmentHttp =
    typeof __DEV__ !== 'undefined' &&
    __DEV__ &&
    API.startsWith('http://');

  if (!API || (!API.startsWith('https://') && !developmentHttp)) {
    throw new Error(
      'Configure EXPO_PUBLIC_API_URL. Em produção, utilize uma URL HTTPS.'
    );
  }

  let response;

  try {
    response = await fetch(`${API}${path}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        ...(options.headers || {}),
      },
    });
  } catch {
    throw new Error(
      'Não foi possível conectar. Verifique sua internet e tente novamente.'
    );
  }

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(
      data.mensagem || `Erro HTTP ${response.status}.`
    );
  }

  return data;
}

export function getImageUrl(imagePath) {
  if (!imagePath) return null;

  if (
    imagePath.startsWith('http://') ||
    imagePath.startsWith('https://')
  ) {
    return imagePath;
  }

  if (imagePath.startsWith('./')) {
    return `${WEB || API}/img/${imagePath.slice(2)}`;
  }

  if (imagePath.startsWith('/uploads/')) {
    return `${API}${imagePath}`;
  }

  if (imagePath.startsWith('/img/')) {
    return `${WEB || API}${imagePath}`;
  }

  if (imagePath.startsWith('/')) {
    return `${API}${imagePath}`;
  }

  return `${WEB || API}/img/${imagePath}`;
}
