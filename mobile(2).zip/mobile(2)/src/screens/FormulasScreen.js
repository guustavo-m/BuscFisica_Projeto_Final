
import React, { useMemo, useState } from 'react';
import {
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';

import { colors, radius } from '../styles/theme';

const formulas = [
  {
    category: 'Cinemática',
    name: 'Velocidade média',
    formula: 'Vm = ΔS / Δt',
    description: 'Relação entre o deslocamento e o intervalo de tempo.',
  },
  {
    category: 'Cinemática',
    name: 'Aceleração média',
    formula: 'a = ΔV / Δt',
    description: 'Variação da velocidade em determinado intervalo de tempo.',
  },
  {
    category: 'Cinemática',
    name: 'Movimento uniforme',
    formula: 'S = S₀ + V · t',
    description: 'Equação horária da posição no movimento uniforme.',
  },
  {
    category: 'Cinemática',
    name: 'Torricelli',
    formula: 'V² = V₀² + 2 · a · ΔS',
    description: 'Relaciona velocidade, aceleração e deslocamento.',
  },
  {
    category: 'Dinâmica',
    name: 'Segunda lei de Newton',
    formula: 'F = m · a',
    description: 'A força resultante é o produto da massa pela aceleração.',
  },
  {
    category: 'Dinâmica',
    name: 'Peso',
    formula: 'P = m · g',
    description: 'Força gravitacional que atua sobre um corpo.',
  },
  {
    category: 'Energia',
    name: 'Energia cinética',
    formula: 'Ec = m · v² / 2',
    description: 'Energia associada ao movimento de um corpo.',
  },
  {
    category: 'Energia',
    name: 'Energia potencial gravitacional',
    formula: 'Ep = m · g · h',
    description: 'Energia associada à altura em relação a um referencial.',
  },
  {
    category: 'Energia',
    name: 'Potência média',
    formula: 'P = ΔE / Δt',
    description: 'Energia transformada ou trabalho realizado por unidade de tempo.',
  },
  {
    category: 'Termologia',
    name: 'Calor sensível',
    formula: 'Q = m · c · ΔT',
    description: 'Quantidade de calor que provoca variação de temperatura.',
  },
  {
    category: 'Ondulatória',
    name: 'Equação fundamental da onda',
    formula: 'v = λ · f',
    description: 'Relaciona velocidade, comprimento de onda e frequência.',
  },
  {
    category: 'Eletricidade',
    name: 'Lei de Ohm',
    formula: 'U = R · i',
    description: 'Relaciona tensão elétrica, resistência e corrente.',
  },
  {
    category: 'Eletricidade',
    name: 'Potência elétrica',
    formula: 'P = U · i',
    description: 'Produto entre tensão elétrica e corrente.',
  },
];

const categories = [
  'Todas',
  'Cinemática',
  'Dinâmica',
  'Energia',
  'Termologia',
  'Ondulatória',
  'Eletricidade',
];

export default function FormulasScreen() {
  const [category, setCategory] = useState('Todas');
  const [search, setSearch] = useState('');

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();

    return formulas.filter((item) => {
      const matchesCategory =
        category === 'Todas' || item.category === category;

      const matchesSearch =
        !term ||
        item.name.toLowerCase().includes(term) ||
        item.formula.toLowerCase().includes(term) ||
        item.description.toLowerCase().includes(term);

      return matchesCategory && matchesSearch;
    });
  }, [category, search]);

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.heading}>
        <Text style={styles.eyebrow}>CONSULTA RÁPIDA</Text>
        <Text style={styles.title}>Fórmulas de Física</Text>
        <Text style={styles.subtitle}>
          Encontre relações e equações importantes para seus estudos.
        </Text>
      </View>

      <TextInput
        style={styles.search}
        placeholder="Pesquisar fórmula ou assunto..."
        placeholderTextColor={colors.textSecondary}
        value={search}
        onChangeText={setSearch}
      />

      <Text style={styles.sectionTitle}>CATEGORIAS</Text>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.categories}
      >
        {categories.map((item) => {
          const active = category === item;

          return (
            <TouchableOpacity
              key={item}
              onPress={() => setCategory(item)}
              style={[
                styles.category,
                active && styles.categoryActive,
              ]}
            >
              <Text
                style={[
                  styles.categoryText,
                  active && styles.categoryTextActive,
                ]}
              >
                {item}
              </Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>

      <View style={styles.resultsHeader}>
        <Text style={styles.sectionTitle}>FÓRMULAS DISPONÍVEIS</Text>
        <Text style={styles.counter}>{filtered.length}</Text>
      </View>

      {filtered.length === 0 ? (
        <View style={styles.empty}>
          <Text style={styles.emptyTitle}>Nenhuma fórmula encontrada.</Text>
          <Text style={styles.emptyText}>
            Tente outro termo ou selecione outra categoria.
          </Text>
        </View>
      ) : (
        filtered.map((item, index) => (
          <View key={`${item.name}-${index}`} style={styles.card}>
            <View style={styles.cardHeader}>
              <Text style={styles.cardCategory}>{item.category}</Text>
            </View>

            <Text style={styles.cardTitle}>{item.name}</Text>

            <View style={styles.formulaBox}>
              <Text style={styles.formula}>{item.formula}</Text>
            </View>

            <Text style={styles.description}>
              {item.description}
            </Text>
          </View>
        ))
      )}

      <Text style={styles.footer}>
        BUSCFÍSICA • APRENDA. PRATIQUE. EVOLUA.
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: 18,
    paddingBottom: 35,
  },
  heading: {
    marginBottom: 18,
  },
  eyebrow: {
    color: colors.lilac,
    fontWeight: '900',
    fontSize: 10,
    letterSpacing: 1.2,
  },
  title: {
    color: colors.dark,
    fontSize: 26,
    fontWeight: '900',
    marginTop: 6,
  },
  subtitle: {
    color: colors.textSecondary,
    fontSize: 13,
    lineHeight: 19,
    marginTop: 7,
  },
  search: {
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    padding: 15,
    fontSize: 14,
    color: colors.text,
  },
  sectionTitle: {
    color: colors.dark,
    fontWeight: '900',
    fontSize: 12,
    letterSpacing: 0.6,
  },
  categories: {
    marginTop: 12,
    marginBottom: 22,
  },
  category: {
    backgroundColor: colors.surface,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: radius.pill,
    borderWidth: 1,
    borderColor: colors.border,
    marginRight: 8,
  },
  categoryActive: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  categoryText: {
    color: colors.primary,
    fontWeight: '700',
    fontSize: 11,
  },
  categoryTextActive: {
    color: '#fff',
  },
  resultsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  counter: {
    color: colors.primary,
    fontWeight: '900',
    backgroundColor: '#eee2f3',
    paddingHorizontal: 11,
    paddingVertical: 5,
    borderRadius: radius.pill,
    overflow: 'hidden',
  },
  card: {
    backgroundColor: colors.surface,
    padding: 16,
    borderRadius: radius.md,
    marginBottom: 12,
    borderLeftWidth: 4,
    borderLeftColor: colors.lilac,
    elevation: 2,
  },
  cardHeader: {
    alignSelf: 'flex-start',
    backgroundColor: '#eee2f3',
    borderRadius: radius.pill,
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  cardCategory: {
    color: colors.primary,
    fontWeight: '900',
    fontSize: 10,
  },
  cardTitle: {
    color: colors.dark,
    fontWeight: '900',
    fontSize: 16,
    marginTop: 12,
  },
  formulaBox: {
    backgroundColor: '#f5eff7',
    padding: 15,
    borderRadius: radius.sm,
    marginTop: 12,
    alignItems: 'center',
  },
  formula: {
    color: colors.primary,
    fontSize: 20,
    fontWeight: '900',
    textAlign: 'center',
  },
  description: {
    color: colors.textSecondary,
    fontSize: 12,
    lineHeight: 18,
    marginTop: 11,
  },
  empty: {
    backgroundColor: colors.surface,
    padding: 22,
    borderRadius: radius.md,
    alignItems: 'center',
  },
  emptyTitle: {
    color: colors.dark,
    fontWeight: '900',
  },
  emptyText: {
    color: colors.textSecondary,
    textAlign: 'center',
    marginTop: 7,
    fontSize: 12,
  },
  footer: {
    textAlign: 'center',
    color: colors.textSecondary,
    fontSize: 9,
    fontWeight: '800',
    marginTop: 20,
  },
});
