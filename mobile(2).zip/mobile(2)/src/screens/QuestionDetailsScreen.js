
import React, { useState } from 'react';

import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Linking,
  Alert,
} from 'react-native';

import { colors, spacing, radius } from '../styles/theme';
import { getImageUrl } from '../services/api';
import CustomButton from '../components/CustomButton';

const alternatives = [
  { key: 'a', label: 'A', field: 'alt_a' },
  { key: 'b', label: 'B', field: 'alt_b' },
  { key: 'c', label: 'C', field: 'alt_c' },
  { key: 'd', label: 'D', field: 'alt_d' },
  { key: 'e', label: 'E', field: 'alt_e' },
];

function getCorrectLetter(answer) {
  if (!answer) return null;

  const match = String(answer)
    .trim()
    .match(/^([A-E])(?:\s*[\).:\-]|\s|$)/i);

  return match ? match[1].toLowerCase() : null;
}

export default function QuestionDetailsScreen({
  question,
  selectedOption,
  onSelectOption,
  onCheckAnswer,
  onBack,
  loading,
}) {
  const [imageError, setImageError] = useState(false);

  if (!question) return null;

  const correctAnswer = getCorrectLetter(question.resp_correta);
  const answered = Boolean(question.resp_correta);

  const imageUrl = question.imagem_url
    ? getImageUrl(question.imagem_url)
    : null;

  async function openVideo() {
    if (!question.videoaula) return;

    try {
      await Linking.openURL(question.videoaula);
    } catch {
      Alert.alert(
        'Não foi possível abrir',
        'Verifique se o endereço da videoaula está correto.'
      );
    }
  }

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
    >
      <TouchableOpacity
        style={styles.backButton}
        onPress={onBack}
      >
        <Text style={styles.backText}>← Voltar às questões</Text>
      </TouchableOpacity>

      <View style={styles.heading}>
        <Text style={styles.eyebrow}>
          {question.sigla || 'VESTIBULAR'} • {question.ano || 'Ano'}
        </Text>

        <Text style={styles.title}>
          Resolução de questão
        </Text>

        <Text style={styles.topic}>
          {question.topico || 'Física'}
        </Text>
      </View>

      <View style={styles.questionCard}>
        <Text style={styles.sectionTitle}>Enunciado</Text>

        <Text style={styles.statement}>
          {question.enunciado || 'Enunciado não disponível.'}
        </Text>

        {imageUrl && !imageError && (
          <Image
            source={{ uri: imageUrl }}
            style={styles.questionImage}
            resizeMode="contain"
            onError={() => setImageError(true)}
          />
        )}

        {imageError && (
          <Text style={styles.imageError}>
            Não foi possível carregar a imagem de apoio.
          </Text>
        )}
      </View>

      <View style={styles.alternativesCard}>
        <Text style={styles.sectionTitle}>
          Escolha uma alternativa
        </Text>

        {alternatives.map((alternative) => {
          const value = question[alternative.field];

          if (!value) return null;

          const isSelected =
            selectedOption === alternative.key;

          const isCorrect =
            answered && correctAnswer === alternative.key;

          const isWrong =
            answered &&
            isSelected &&
            correctAnswer !== alternative.key;

          return (
            <TouchableOpacity
              key={alternative.key}
              activeOpacity={0.8}
              disabled={answered}
              onPress={() => onSelectOption(alternative.key)}
              style={[
                styles.alternative,
                isSelected && styles.selectedAlternative,
                isCorrect && styles.correctAlternative,
                isWrong && styles.wrongAlternative,
              ]}
            >
              <View
                style={[
                  styles.letter,
                  isSelected && styles.selectedLetter,
                  isCorrect && styles.correctLetter,
                  isWrong && styles.wrongLetter,
                ]}
              >
                <Text
                  style={[
                    styles.letterText,
                    (isSelected || isCorrect || isWrong) &&
                      styles.activeLetterText,
                  ]}
                >
                  {alternative.label}
                </Text>
              </View>

              <Text style={styles.alternativeText}>
                {value}
              </Text>
            </TouchableOpacity>
          );
        })}

        {!answered && (
          <CustomButton
            title="Conferir resposta"
            onPress={onCheckAnswer}
            loading={loading}
            disabled={!selectedOption}
          />
        )}

        {answered && (
          <View style={styles.resultBox}>
            <Text style={styles.resultTitle}>
              {selectedOption === correctAnswer
                ? 'Resposta correta!'
                : 'Resposta incorreta'}
            </Text>

            <Text style={styles.resultText}>
              Alternativa correta: {correctAnswer?.toUpperCase() || 'Não identificada'}
            </Text>
          </View>
        )}
      </View>

      {answered && (
        <View style={styles.explanationCard}>
          <Text style={styles.sectionTitle}>
            Explicação do professor
          </Text>

          <Text style={styles.explanation}>
            {question.explicacao_prof ||
              'Nenhuma explicação foi cadastrada para esta questão.'}
          </Text>

          {question.videoaula && (
            <TouchableOpacity
              style={styles.videoButton}
              onPress={openVideo}
            >
              <Text style={styles.videoText}>
                ▶ Assistir à videoaula
              </Text>
            </TouchableOpacity>
          )}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: spacing.medium,
    paddingBottom: 110,
  },
  backButton: {
    alignSelf: 'flex-start',
    paddingVertical: spacing.small,
    marginBottom: spacing.medium,
  },
  backText: {
    color: colors.primary,
    fontSize: 14,
    fontWeight: '800',
  },
  heading: {
    marginBottom: spacing.large,
  },
  eyebrow: {
    color: colors.lilac,
    fontSize: 11,
    fontWeight: '900',
    letterSpacing: 1,
    marginBottom: spacing.small,
  },
  title: {
    color: colors.dark,
    fontSize: 25,
    fontWeight: '900',
  },
  topic: {
    color: colors.textSecondary,
    marginTop: spacing.small,
    fontSize: 13,
  },
  questionCard: {
    backgroundColor: colors.surface,
    borderRadius: radius.large,
    padding: spacing.large,
    marginBottom: spacing.medium,
    borderWidth: 1,
    borderColor: colors.border,
  },
  sectionTitle: {
    color: colors.dark,
    fontSize: 17,
    fontWeight: '900',
    marginBottom: spacing.medium,
  },
  statement: {
    color: colors.text,
    fontSize: 15,
    lineHeight: 24,
  },
  questionImage: {
    width: '100%',
    height: 230,
    marginTop: spacing.large,
    backgroundColor: colors.surfaceSoft,
    borderRadius: radius.medium,
  },
  imageError: {
    color: colors.danger,
    fontSize: 12,
    marginTop: spacing.medium,
  },
  alternativesCard: {
    backgroundColor: colors.surface,
    borderRadius: radius.large,
    padding: spacing.large,
    marginBottom: spacing.medium,
    borderWidth: 1,
    borderColor: colors.border,
  },
  alternative: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.medium,
    padding: spacing.medium,
    marginBottom: spacing.small,
    backgroundColor: colors.surfaceSoft,
  },
  selectedAlternative: {
    borderColor: colors.primary,
    backgroundColor: '#f3eafa',
  },
  correctAlternative: {
    borderColor: colors.success,
    backgroundColor: '#e8f7ed',
  },
  wrongAlternative: {
    borderColor: colors.danger,
    backgroundColor: '#fff0f0',
  },
  letter: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: spacing.medium,
  },
  selectedLetter: {
    backgroundColor: colors.primary,
  },
  correctLetter: {
    backgroundColor: colors.success,
  },
  wrongLetter: {
    backgroundColor: colors.danger,
  },
  letterText: {
    color: colors.text,
    fontWeight: '900',
  },
  activeLetterText: {
    color: '#FFFFFF',
  },
  alternativeText: {
    flex: 1,
    color: colors.text,
    fontSize: 14,
    lineHeight: 21,
  },
  resultBox: {
    padding: spacing.medium,
    borderRadius: radius.medium,
    backgroundColor: colors.surfaceSoft,
    marginTop: spacing.medium,
  },
  resultTitle: {
    color: colors.dark,
    fontWeight: '900',
    fontSize: 16,
  },
  resultText: {
    color: colors.textSecondary,
    marginTop: spacing.small,
    fontSize: 13,
  },
  explanationCard: {
    backgroundColor: colors.surface,
    borderRadius: radius.large,
    padding: spacing.large,
    borderWidth: 1,
    borderColor: colors.border,
  },
  explanation: {
    color: colors.text,
    fontSize: 14,
    lineHeight: 23,
  },
  videoButton: {
    marginTop: spacing.large,
    padding: spacing.medium,
    borderRadius: radius.medium,
    backgroundColor: colors.primary,
    alignItems: 'center',
  },
  videoText: {
    color: '#FFFFFF',
    fontWeight: '800',
  },
});
