
import React, { useEffect, useState } from 'react';

import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native';

import { StatusBar } from 'expo-status-bar';

import LoginScreen from './src/screens/LoginScreen';
import HomeScreen from './src/screens/HomeScreen';
import QuestionsScreen from './src/screens/QuestionsScreen';
import QuestionDetailsScreen from './src/screens/QuestionDetailsScreen';
import FormulasScreen from './src/screens/FormulasScreen';

import { request } from './src/services/api';

import {
  getStoredValue,
  setStoredValue,
  deleteStoredValue,
} from './src/services/storage';

import { colors, spacing, radius } from './src/styles/theme';

export default function App() {
  // AUTENTICAÇÃO
  const [token, setToken] = useState(null);
  const [user, setUser] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [authSubmitting, setAuthSubmitting] = useState(false);

  // NAVEGAÇÃO
  const [screen, setScreen] = useState('login');

  // QUESTÕES
  const [items, setItems] = useState([]);
  const [selected, setSelected] = useState(null);
  const [selectedOption, setSelectedOption] = useState('');

  // FILTROS
  const [vests, setVests] = useState([]);
  const [materias, setMaterias] = useState([]);
  const [topicos, setTopicos] = useState([]);

  const [vest, setVest] = useState('');
  const [materia, setMateria] = useState('');
  const [topico, setTopico] = useState('');

  // CARREGAMENTO E ERROS
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [answerLoading, setAnswerLoading] = useState(false);
  const [error, setError] = useState('');

  // =====================================================
  // FUNÇÕES AUXILIARES
  // =====================================================

  function extractArray(data, possibleKeys = []) {
    if (Array.isArray(data)) return data;

    for (const key of possibleKeys) {
      if (Array.isArray(data?.[key])) {
        return data[key];
      }
    }

    return [];
  }

  function showMessage(title, message) {
    Alert.alert(title, message);
  }

  // =====================================================
  // RESTAURAR SESSÃO
  // =====================================================

  useEffect(() => {
    async function restoreSession() {
      try {
        const savedToken = await getStoredValue('jwt');
        const savedUser = await getStoredValue('user');

        if (savedToken && savedUser) {
          const parsedUser = JSON.parse(savedUser);

          setToken(savedToken);
          setUser(parsedUser);
          setScreen('home');
        } else {
          setScreen('login');
        }
      } catch (err) {
        console.log('Erro ao restaurar sessão:', err);
        setScreen('login');
      } finally {
        setAuthLoading(false);
      }
    }

    restoreSession();
  }, []);

  // =====================================================
  // LOGIN E CADASTRO
  // =====================================================

  async function handleAuthenticate({
    register,
    nome,
    email,
    password,
  }) {
    setAuthSubmitting(true);
    setError('');

    try {
      if (register) {
        await request('/auth/registrar', null, {
          method: 'POST',
          body: JSON.stringify({
            nome,
            email,
            password,
          }),
        });

        showMessage(
          'Cadastro realizado!',
          'Sua conta foi criada. Agora faça login para continuar.'
        );

        return;
      }

      const data = await request('/auth/login', null, {
        method: 'POST',
        body: JSON.stringify({
          email,
          password,
        }),
      });

      const newToken = data.token || data.jwt;
      const newUser = data.usuario || data.user || data;

      if (!newToken) {
        throw new Error(
          'O servidor não retornou o token de autenticação.'
        );
      }

      setToken(newToken);
      setUser(newUser);

      await setStoredValue('jwt', newToken);
      await setStoredValue('user', JSON.stringify(newUser));

      setScreen('home');

    } catch (err) {
      console.log('Erro na autenticação:', err);
      showMessage(
        'Não foi possível continuar',
        err.message || 'Verifique seus dados e tente novamente.'
      );
    } finally {
      setAuthSubmitting(false);
    }
  }

  // =====================================================
  // LOGOUT
  // =====================================================

  async function handleLogout() {
    try {
      await deleteStoredValue('jwt');
      await deleteStoredValue('user');
    } catch (err) {
      console.log('Erro ao limpar sessão:', err);
    }

    setToken(null);
    setUser(null);
    setItems([]);
    setSelected(null);
    setSelectedOption('');

    setVest('');
    setMateria('');
    setTopico('');

    setScreen('login');
  }

  // =====================================================
  // CARREGAR FILTROS
  // =====================================================

  async function loadFilters() {
    try {
      const [vestData, materiaData, topicoData] =
        await Promise.all([
          request('/vestibulares', token),
          request('/materia', token),
          request('/topico', token),
        ]);

      setVests(
        extractArray(vestData, ['vestibulares', 'dados'])
      );

      setMaterias(
        extractArray(materiaData, ['materias', 'dados'])
      );

      setTopicos(
        extractArray(topicoData, ['topicos', 'dados'])
      );

    } catch (err) {
      console.log('Erro ao carregar filtros:', err);
    }
  }

  // =====================================================
  // CARREGAR QUESTÕES
  // =====================================================

  async function loadQuestions(isRefresh = false) {
    if (!token) return;

    if (isRefresh) {
      setRefreshing(true);
    } else {
      setLoading(true);
    }

    setError('');

    try {
      const hasFilters = Boolean(vest || materia || topico);

      let path = '/questoes';

      if (hasFilters) {
        const params = new URLSearchParams();

        if (vest) {
          const selectedVest = vests.find(
            (item) => String(item.id) === String(vest)
          );

          if (selectedVest?.sigla) {
            params.append('vestibular', selectedVest.sigla);
          }
        }

        if (materia) {
          const selectedMateria = materias.find(
            (item) =>
              String(item.id_mat ?? item.id) === String(materia)
          );

          if (selectedMateria?.nome_mat) {
            params.append('materia', selectedMateria.nome_mat);
          }
        }

        if (topico) {
          const selectedTopic = topicos.find(
            (item) =>
              String(item.id_top ?? item.id) === String(topico)
          );

          if (selectedTopic?.nome_top) {
            params.append('topico', selectedTopic.nome_top);
          }
        }

        if (params.toString()) {
          path = `/questoes/filtro?${params.toString()}`;
        }
      }

      const data = await request(path, token);

      const questions = extractArray(data, [
        'questoes',
        'dados',
        'resultados',
      ]);

      setItems(questions);

    } catch (err) {
      console.log('Erro ao carregar questões:', err);

      setError(err.message || 'Erro ao carregar questões.');

      showMessage(
        'Erro ao carregar questões',
        err.message || 'Tente novamente.'
      );
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  // =====================================================
  // CARREGAR DADOS INICIAIS
  // =====================================================

  useEffect(() => {
    if (token && !authLoading) {
      loadFilters();
      loadQuestions();
    }
  }, [token, authLoading]);

  // =====================================================
  // FILTROS
  // =====================================================

  function applyFilters() {
    loadQuestions();
  }

  function clearFilters() {
    setVest('');
    setMateria('');
    setTopico('');

    loadQuestionsWithoutFilters();
  }

  async function loadQuestionsWithoutFilters() {
    if (!token) return;

    setLoading(true);
    setError('');

    try {
      const data = await request('/questoes', token);

      setItems(
        extractArray(data, [
          'questoes',
          'dados',
          'resultados',
        ])
      );
    } catch (err) {
      console.log('Erro ao limpar filtros:', err);

      showMessage(
        'Erro',
        err.message || 'Não foi possível carregar as questões.'
      );
    } finally {
      setLoading(false);
    }
  }

  // =====================================================
  // ABRIR QUESTÃO
  // =====================================================

  function openQuestion(question) {
    setSelected(question);
    setSelectedOption('');
    setScreen('detail');
  }

  // =====================================================
  // CONFERIR RESPOSTA
  // =====================================================

  async function checkAnswer() {
    if (!selectedOption) {
      showMessage(
        'Atenção',
        'Selecione uma alternativa antes de conferir.'
      );

      return;
    }

    setAnswerLoading(true);

    try {
      const data = await request(
        `/questoes/${selected.idq}`,
        token
      );

      const questionData =
        data.questao || data.questoes || data.dados || data;

      setSelected({
        ...selected,
        ...questionData,
      });

    } catch (err) {
      console.log('Erro ao consultar resposta:', err);

      showMessage(
        'Erro ao consultar resposta',
        err.message || 'Não foi possível consultar a resposta.'
      );
    } finally {
      setAnswerLoading(false);
    }
  }

  // =====================================================
  // NAVEGAÇÃO
  // =====================================================

  function navigate(destination) {
    if (destination === 'list') {
      setScreen('list');

      if (items.length === 0) {
        loadQuestions();
      }

      return;
    }

    setScreen(destination);
  }

  // =====================================================
  // CARREGAMENTO INICIAL
  // =====================================================

  if (authLoading) {
    return (
      <View style={styles.loadingScreen}>
        <ActivityIndicator
          size="large"
          color={colors.primary}
        />

        <Text style={styles.loadingText}>
          Preparando o BuscFísica...
        </Text>
      </View>
    );
  }

  // =====================================================
  // LOGIN
  // =====================================================

  if (!token || screen === 'login') {
    return (
      <>
        <StatusBar style="light" />

        <LoginScreen
          onAuthenticate={handleAuthenticate}
          loading={authSubmitting}
        />
      </>
    );
  }

  // =====================================================
  // TELAS PRINCIPAIS
  // =====================================================

  return (
    <View style={styles.app}>
      <StatusBar style="light" />

      {screen !== 'detail' && (
        <View style={styles.topBar}>
          <View>
            <Text style={styles.brand}>BUSCFÍSICA</Text>
            <Text style={styles.brandSubtitle}>
              Sua preparação começa aqui.
            </Text>
          </View>

          <TouchableOpacity
            style={styles.logoutButton}
            onPress={handleLogout}
          >
            <Text style={styles.logoutText}>Sair</Text>
          </TouchableOpacity>
        </View>
      )}

      <View style={styles.main}>
        {screen === 'home' && (
          <HomeScreen
            user={user}
            onNavigate={navigate}
            onLogout={handleLogout}
          />
        )}

        {screen === 'list' && (
          <QuestionsScreen
            items={items}
            vests={vests}
            materias={materias}
            topicos={topicos}
            vest={vest}
            materia={materia}
            topico={topico}
            onVestChange={setVest}
            onMateriaChange={setMateria}
            onTopicoChange={setTopico}
            onApplyFilters={applyFilters}
            onClearFilters={clearFilters}
            onOpenQuestion={openQuestion}
            loading={loading}
            refreshing={refreshing}
            onRefresh={() => loadQuestions(true)}
          />
        )}

        {screen === 'detail' && (
          <QuestionDetailsScreen
            question={selected}
            selectedOption={selectedOption}
            onSelectOption={setSelectedOption}
            onCheckAnswer={checkAnswer}
            onBack={() => setScreen('list')}
            loading={answerLoading}
          />
        )}

        {screen === 'formulas' && (
          <FormulasScreen />
        )}
      </View>

      {screen !== 'detail' && (
        <View style={styles.bottomNavigation}>
          <NavItem
            label="Início"
            symbol="⌂"
            active={screen === 'home'}
            onPress={() => navigate('home')}
          />

          <NavItem
            label="Questões"
            symbol="▤"
            active={screen === 'list'}
            onPress={() => navigate('list')}
          />

          <NavItem
            label="Fórmulas"
            symbol="ƒ"
            active={screen === 'formulas'}
            onPress={() => navigate('formulas')}
          />
        </View>
      )}
    </View>
  );
}

// =======================================================
// ITEM DA NAVEGAÇÃO INFERIOR
// =======================================================

function NavItem({ label, symbol, active, onPress }) {
  return (
    <TouchableOpacity
      style={styles.navItem}
      onPress={onPress}
      activeOpacity={0.8}
    >
      <Text
        style={[
          styles.navSymbol,
          active && styles.navActive,
        ]}
      >
        {symbol}
      </Text>

      <Text
        style={[
          styles.navLabel,
          active && styles.navActive,
        ]}
      >
        {label}
      </Text>
    </TouchableOpacity>
  );
}

// =======================================================
// ESTILOS
// =======================================================

const styles = StyleSheet.create({
  app: {
    flex: 1,
    backgroundColor: colors.background,
  },

  main: {
    flex: 1,
  },

  loadingScreen: {
    flex: 1,
    backgroundColor: colors.background,
    justifyContent: 'center',
    alignItems: 'center',
  },

  loadingText: {
    color: colors.primary,
    fontWeight: '700',
    marginTop: spacing.medium,
  },

  topBar: {
    backgroundColor: colors.dark,
    paddingHorizontal: spacing.large,
    paddingVertical: spacing.medium,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  brand: {
    color: '#FFFFFF',
    fontSize: 19,
    fontWeight: '900',
    letterSpacing: 1,
  },

  brandSubtitle: {
    color: '#d9c6e2',
    fontSize: 10,
    marginTop: 3,
  },

  logoutButton: {
    borderWidth: 1,
    borderColor: '#9b78a8',
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: radius.medium,
  },

  logoutText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '800',
  },

  bottomNavigation: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    borderTopWidth: 1,
    borderTopColor: colors.border,
    paddingTop: 10,
    paddingBottom: 18,
    justifyContent: 'space-around',
  },

  navItem: {
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
    paddingVertical: 4,
  },

  navSymbol: {
    fontSize: 23,
    color: colors.textSecondary,
    fontWeight: '700',
  },

  navLabel: {
    fontSize: 11,
    color: colors.textSecondary,
    marginTop: 3,
    fontWeight: '700',
  },

  navActive: {
    color: colors.primary,
    fontWeight: '900',
  },
});
