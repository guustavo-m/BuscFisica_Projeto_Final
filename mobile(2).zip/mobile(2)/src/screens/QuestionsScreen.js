
import React from 'react';

import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';

import { colors, spacing, radius } from '../styles/theme';
import QuestionCard from '../components/QuestionCard';

function FilterGroup({
  title,
  options,
  selected,
  onSelect,
  getLabel,
  getValue,
}) {
  return (
    <View style={styles.filterGroup}>
      <Text style={styles.filterTitle}>{title}</Text>

      <View style={styles.chips}>
        {options.map((item, index) => {
          const value = String(getValue(item));
          const active = String(selected) === value;

          return (
            <TouchableOpacity
              key={`${value}-${index}`}
              style={[
                styles.chip,
                active && styles.chipActive,
              ]}
              onPress={() => onSelect(active ? '' : value)}
            >
              <Text
                style={[
                  styles.chipText,
                  active && styles.chipTextActive,
                ]}
              >
                {getLabel(item)}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
}

export default function QuestionsScreen({
  items = [],
  vests = [],
  materias = [],
  topicos = [],

  vest,
  materia,
  topico,

  onVestChange,
  onMateriaChange,
  onTopicoChange,

  onApplyFilters,
  onClearFilters,
  onOpenQuestion,

  loading,
  refreshing,
  onRefresh,
}) {
  const header = (
    <View>
      <View style={styles.heading}>
        <Text style={styles.eyebrow}>SEU TREINAMENTO</Text>
        <Text style={styles.title}>Banco de questões</Text>
        <Text style={styles.subtitle}>
          Encontre questões e pratique seus conhecimentos em Física.
        </Text>
      </View>

      <View style={styles.filterCard}>
        <Text style={styles.filterHeading}>Filtrar questões</Text>

        <FilterGroup
          title="Vestibular"
          options={vests}
          selected={vest}
          onSelect={onVestChange}
          getLabel={(item) => item.sigla || item.nome || 'Vestibular'}
          getValue={(item) => item.id}
        />

        <FilterGroup
          title="Matéria"
          options={materias}
          selected={materia}
          onSelect={onMateriaChange}
          getLabel={(item) => item.nome_mat || item.nome || 'Matéria'}
          getValue={(item) => item.id_mat ?? item.id}
        />

        <FilterGroup
          title="Tópico"
          options={topicos}
          selected={topico}
          onSelect={onTopicoChange}
          getLabel={(item) => item.nome_top || item.nome || 'Tópico'}
          getValue={(item) => item.id_top ?? item.id}
        />

        <View style={styles.filterButtons}>
          <TouchableOpacity
            style={styles.clearButton}
            onPress={onClearFilters}
          >
            <Text style={styles.clearText}>Limpar</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.applyButton}
            onPress={onApplyFilters}
          >
            <Text style={styles.applyText}>Aplicar filtros</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.listHeading}>
        <Text style={styles.listTitle}>Questões disponíveis</Text>
        <Text style={styles.count}>{items.length} encontradas</Text>
      </View>
    </View>
  );

  return (
    <FlatList
      style={styles.container}
      contentContainerStyle={styles.content}
      data={items}
      keyExtractor={(item, index) =>
        String(item.idq ?? index)
      }
      ListHeaderComponent={header}
      renderItem={({ item }) => (
        <QuestionCard
          question={item}
          onPress={() => onOpenQuestion(item)}
        />
      )}
      ListEmptyComponent={
        <View style={styles.empty}>
          {loading ? (
            <ActivityIndicator
              size="large"
              color={colors.primary}
            />
          ) : (
            <>
              <Text style={styles.emptyTitle}>
                Nenhuma questão encontrada
              </Text>
              <Text style={styles.emptyText}>
                Experimente alterar os filtros ou limpar sua pesquisa.
              </Text>
            </>
          )}
        </View>
      }
      refreshControl={
        <RefreshControl
          refreshing={Boolean(refreshing)}
          onRefresh={onRefresh}
          tintColor={colors.primary}
          colors={[colors.primary]}
        />
      }
    />
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: spacing.medium,
    paddingBottom: 110,
  },
  heading: {
    marginBottom: spacing.large,
  },
  eyebrow: {
    color: colors.lilac,
    fontSize: 11,
    fontWeight: '900',
    letterSpacing: 1.5,
    marginBottom: spacing.small,
  },
  title: {
    color: colors.dark,
    fontSize: 27,
    fontWeight: '900',
  },
  subtitle: {
    color: colors.textSecondary,
    fontSize: 14,
    lineHeight: 21,
    marginTop: spacing.small,
  },
  filterCard: {
    backgroundColor: colors.surface,
    borderRadius: radius.large,
    padding: spacing.large,
    borderWidth: 1,
    borderColor: colors.border,
    marginBottom: spacing.large,
  },
  filterHeading: {
    color: colors.dark,
    fontSize: 17,
    fontWeight: '900',
    marginBottom: spacing.medium,
  },
  filterGroup: {
    marginBottom: spacing.medium,
  },
  filterTitle: {
    color: colors.text,
    fontSize: 13,
    fontWeight: '800',
    marginBottom: spacing.small,
  },
  chips: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  chip: {
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surfaceSoft,
    borderRadius: radius.round,
    paddingVertical: 8,
    paddingHorizontal: 12,
  },
  chipActive: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  chipText: {
    color: colors.textSecondary,
    fontSize: 12,
    fontWeight: '700',
  },
  chipTextActive: {
    color: '#FFFFFF',
  },
  filterButtons: {
    flexDirection: 'row',
    gap: 10,
    marginTop: spacing.small,
  },
  clearButton: {
    flex: 1,
    padding: 13,
    alignItems: 'center',
    borderRadius: radius.medium,
    borderWidth: 1,
    borderColor: colors.border,
  },
  clearText: {
    color: colors.textSecondary,
    fontWeight: '800',
  },
  applyButton: {
    flex: 2,
    padding: 13,
    alignItems: 'center',
    borderRadius: radius.medium,
    backgroundColor: colors.primary,
  },
  applyText: {
    color: '#FFFFFF',
    fontWeight: '800',
  },
  listHeading: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.medium,
  },
  listTitle: {
    color: colors.dark,
    fontSize: 17,
    fontWeight: '900',
  },
  count: {
    color: colors.textSecondary,
    fontSize: 11,
  },
  empty: {
    alignItems: 'center',
    padding: spacing.xlarge,
  },
  emptyTitle: {
    color: colors.dark,
    fontWeight: '800',
    fontSize: 15,
    textAlign: 'center',
  },
  emptyText: {
    color: colors.textSecondary,
    fontSize: 13,
    textAlign: 'center',
    marginTop: spacing.small,
    lineHeight: 20,
  },
});
