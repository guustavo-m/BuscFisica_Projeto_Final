
import React from 'react';
import {
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

import { colors, radius } from '../styles/theme';

export default function HomeScreen({ user, onNavigate, onLogout }) {
  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.welcome}>
        <View style={styles.welcomeText}>
          <Text style={styles.greeting}>OLÁ, ESTUDANTE!</Text>
          <Text style={styles.name}>
            {user?.nome || 'Vamos estudar?'}
          </Text>
          <Text style={styles.subtitle}>
            Seu próximo aprendizado começa aqui.
          </Text>
        </View>

        <TouchableOpacity onPress={onLogout}>
          <Text style={styles.logout}>SAIR</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.hero}>
        <Text style={styles.heroLabel}>BUSCFÍSICA</Text>

        <Text style={styles.heroTitle}>
          DOMINE A FÍSICA PARA O VESTIBULAR.
        </Text>

        <Text style={styles.heroDescription}>
          Explore questões, revise conceitos e fortaleça seus conhecimentos
          para conquistar seus objetivos.
        </Text>

        <TouchableOpacity
          style={styles.heroButton}
          onPress={() => onNavigate('list')}
        >
          <Text style={styles.heroButtonText}>
            EXPLORAR QUESTÕES →
          </Text>
        </TouchableOpacity>

        <Text style={styles.formulaDecoration}>E = mc²</Text>
      </View>

      <Text style={styles.sectionTitle}>O QUE VOCÊ DESEJA FAZER?</Text>

      <View style={styles.cards}>
        <TouchableOpacity
          style={styles.card}
          onPress={() => onNavigate('list')}
        >
          <View style={styles.iconBox}>
            <Text style={styles.icon}>▤</Text>
          </View>

          <Text style={styles.cardTitle}>Questões</Text>
          <Text style={styles.cardDescription}>
            Pratique com exercícios de vestibulares.
          </Text>

          <Text style={styles.cardLink}>ACESSAR →</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.card}
          onPress={() => onNavigate('formulas')}
        >
          <View style={styles.iconBox}>
            <Text style={styles.icon}>ƒ</Text>
          </View>

          <Text style={styles.cardTitle}>Fórmulas</Text>
          <Text style={styles.cardDescription}>
            Consulte fórmulas e conceitos de física.
          </Text>

          <Text style={styles.cardLink}>CONSULTAR →</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.tip}>
        <Text style={styles.tipTitle}>UMA DICA PARA HOJE</Text>
        <Text style={styles.tipText}>
          A prática constante ajuda a transformar conhecimento em confiança.
          Reserve um momento para resolver algumas questões!
        </Text>
      </View>

      <Text style={styles.footer}>
        BUSCFÍSICA • SEU CONHECIMENTO EM MOVIMENTO
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: 18,
    paddingBottom: 30,
  },
  welcome: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  welcomeText: {
    flex: 1,
    paddingRight: 10,
  },
  greeting: {
    color: colors.lilac,
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 1,
  },
  name: {
    color: colors.dark,
    fontSize: 22,
    fontWeight: '900',
    marginTop: 3,
  },
  subtitle: {
    color: colors.textSecondary,
    fontSize: 12,
    marginTop: 4,
  },
  logout: {
    color: colors.primary,
    fontWeight: '900',
    fontSize: 12,
    padding: 8,
  },
  hero: {
    backgroundColor: colors.dark,
    padding: 23,
    borderRadius: radius.lg,
    overflow: 'hidden',
    minHeight: 280,
  },
  heroLabel: {
    color: '#d8a9e8',
    fontSize: 11,
    fontWeight: '900',
    letterSpacing: 2,
  },
  heroTitle: {
    color: '#fff',
    fontSize: 27,
    lineHeight: 34,
    fontWeight: '900',
    marginTop: 18,
    maxWidth: 300,
  },
  heroDescription: {
    color: '#eadcf0',
    fontSize: 13,
    lineHeight: 20,
    marginTop: 12,
  },
  heroButton: {
    alignSelf: 'flex-start',
    backgroundColor: colors.lilac,
    paddingHorizontal: 16,
    paddingVertical: 13,
    borderRadius: radius.md,
    marginTop: 20,
  },
  heroButtonText: {
    color: '#fff',
    fontWeight: '900',
    fontSize: 11,
  },
  formulaDecoration: {
    position: 'absolute',
    right: 15,
    bottom: 12,
    color: 'rgba(255,255,255,0.09)',
    fontSize: 35,
    fontWeight: '900',
  },
  sectionTitle: {
    color: colors.dark,
    fontSize: 14,
    fontWeight: '900',
    marginTop: 27,
    marginBottom: 13,
  },
  cards: {
    flexDirection: 'row',
    gap: 12,
  },
  card: {
    flex: 1,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    padding: 14,
    minHeight: 185,
    elevation: 2,
  },
  iconBox: {
    width: 40,
    height: 40,
    backgroundColor: '#eee2f3',
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  icon: {
    color: colors.primary,
    fontSize: 25,
    fontWeight: '900',
  },
  cardTitle: {
    color: colors.dark,
    fontWeight: '900',
    fontSize: 16,
    marginTop: 13,
  },
  cardDescription: {
    color: colors.textSecondary,
    fontSize: 11,
    lineHeight: 16,
    marginTop: 6,
    flex: 1,
  },
  cardLink: {
    color: colors.lilac,
    fontWeight: '900',
    fontSize: 10,
    marginTop: 12,
  },
  tip: {
    backgroundColor: '#eee2f3',
    borderRadius: radius.md,
    padding: 17,
    marginTop: 20,
  },
  tipTitle: {
    color: colors.primary,
    fontSize: 11,
    fontWeight: '900',
    letterSpacing: 0.8,
  },
  tipText: {
    color: colors.text,
    fontSize: 13,
    lineHeight: 20,
    marginTop: 7,
  },
  footer: {
    textAlign: 'center',
    color: colors.textSecondary,
    fontSize: 9,
    fontWeight: '800',
    marginTop: 25,
  },
});
