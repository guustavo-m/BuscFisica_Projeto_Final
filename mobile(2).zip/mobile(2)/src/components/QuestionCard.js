
import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';

import { colors, spacing, radius } from '../styles/theme';

export default function QuestionCard({ question, onPress }) {
  return (
    <TouchableOpacity
      style={styles.card}
      activeOpacity={0.8}
      onPress={onPress}
    >
      <View style={styles.top}>
        <Text style={styles.vestibular}>
          {question.sigla || 'Vestibular'}
        </Text>

        <Text style={styles.year}>
          {question.ano || 'Ano não informado'}
        </Text>
      </View>

      <Text style={styles.topic}>
        {question.topico || 'Física'}
      </Text>

      <Text style={styles.statement} numberOfLines={3}>
        {question.enunciado || 'Enunciado não disponível.'}
      </Text>

      <View style={styles.footer}>
        <Text style={styles.difficulty}>
          {question.dificuldade || 'Nível não informado'}
        </Text>

        <Text style={styles.open}>
          Resolver questão →
        </Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.large,
    padding: spacing.large,
    marginBottom: spacing.medium,
    borderWidth: 1,
    borderColor: colors.border,
  },
  top: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.small,
  },
  vestibular: {
    color: colors.primary,
    fontWeight: '800',
    fontSize: 13,
  },
  year: {
    color: colors.textSecondary,
    fontSize: 12,
  },
  topic: {
    color: colors.lilac,
    fontSize: 12,
    fontWeight: '700',
    marginBottom: spacing.small,
  },
  statement: {
    color: colors.text,
    fontSize: 15,
    lineHeight: 22,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: spacing.large,
  },
  difficulty: {
    color: colors.textSecondary,
    fontSize: 12,
  },
  open: {
    color: colors.primary,
    fontSize: 13,
    fontWeight: '800',
  },
});
