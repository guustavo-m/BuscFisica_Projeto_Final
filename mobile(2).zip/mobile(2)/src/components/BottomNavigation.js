
import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';

import { colors } from '../styles/theme';

const tabs = [
  { id: 'home', label: 'Início', symbol: '⌂' },
  { id: 'list', label: 'Questões', symbol: '▤' },
  { id: 'formulas', label: 'Fórmulas', symbol: 'ƒ' },
];

export default function BottomNavigation({ active, onChange }) {
  return (
    <View style={styles.container}>
      {tabs.map((tab) => {
        const selected = active === tab.id;

        return (
          <TouchableOpacity
            key={tab.id}
            style={styles.tab}
            activeOpacity={0.75}
            onPress={() => onChange(tab.id)}
          >
            <Text style={[
              styles.symbol,
              selected && styles.activeText,
            ]}>
              {tab.symbol}
            </Text>

            <Text style={[
              styles.label,
              selected && styles.activeText,
            ]}>
              {tab.label}
            </Text>

            {selected && <View style={styles.indicator} />}
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: colors.border,
    paddingTop: 9,
    paddingBottom: 8,
    justifyContent: 'space-around',
  },
  tab: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 52,
  },
  symbol: {
    fontSize: 22,
    color: colors.textSecondary,
    fontWeight: '700',
  },
  label: {
    fontSize: 11,
    color: colors.textSecondary,
    fontWeight: '700',
    marginTop: 2,
  },
  activeText: {
    color: colors.primary,
  },
  indicator: {
    width: 22,
    height: 3,
    borderRadius: 5,
    backgroundColor: colors.lilac,
    marginTop: 4,
  },
});
