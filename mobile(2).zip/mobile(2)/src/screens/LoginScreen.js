
import React, { useState } from 'react';
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';

import CustomButton from '../components/CustomButton';
import { colors, radius } from '../styles/theme';

export default function LoginScreen({ onAuthenticate }) {
  const [register, setRegister] = useState(false);
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function submit() {
    setError('');

    if (!email.trim() || !password || (register && !nome.trim())) {
      setError('Preencha todos os campos.');
      return;
    }

    if (register && password.length < 8) {
      setError('A senha precisa ter pelo menos 8 caracteres.');
      return;
    }

    setLoading(true);

    try {
      await onAuthenticate({
        register,
        nome: nome.trim(),
        email: email.trim(),
        password,
      });

      if (register) {
        setRegister(false);
        setPassword('');
      }
    } catch (e) {
      setError(e.message || 'Não foi possível realizar a operação.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView
        contentContainerStyle={styles.content}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.brandArea}>
          <View style={styles.logoCircle}>
            <Text style={styles.logoSymbol}>ƒ</Text>
          </View>

          <Text style={styles.brand}>BUSCFÍSICA</Text>
          <Text style={styles.tagline}>
            Seu conhecimento em movimento
          </Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.eyebrow}>
            {register ? 'FAÇA PARTE' : 'ÁREA DO ESTUDANTE'}
          </Text>

          <Text style={styles.title}>
            {register ? 'Crie sua conta.' : 'Bem-vindo!'}
          </Text>

          <Text style={styles.description}>
            {register
              ? 'Cadastre-se e comece a preparar seu futuro.'
              : 'Entre na sua conta e continue sua jornada de aprendizado.'}
          </Text>

          {register && (
            <TextInput
              style={styles.input}
              placeholder="Nome completo"
              placeholderTextColor={colors.textSecondary}
              value={nome}
              onChangeText={setNome}
              autoCapitalize="words"
            />
          )}

          <TextInput
            style={styles.input}
            placeholder="E-mail"
            placeholderTextColor={colors.textSecondary}
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
          />

          <TextInput
            style={styles.input}
            placeholder="Senha"
            placeholderTextColor={colors.textSecondary}
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            autoCapitalize="none"
          />

          {!!error && (
            <View style={styles.errorBox}>
              <Text style={styles.errorText}>{error}</Text>
            </View>
          )}

          <CustomButton
            title={register ? 'CRIAR CONTA' : 'ENTRAR'}
            onPress={submit}
            loading={loading}
            disabled={loading}
          />

          <TouchableOpacity
            style={styles.switchButton}
            onPress={() => {
              setRegister(!register);
              setError('');
            }}
          >
            <Text style={styles.switchText}>
              {register
                ? 'Já possui uma conta? Entrar'
                : 'Ainda não possui conta? Criar conta'}
            </Text>
          </TouchableOpacity>
        </View>

        <Text style={styles.footer}>
          BUSCFÍSICA • APRENDA. PRATIQUE. EVOLUA.
        </Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 22,
  },
  brandArea: {
    alignItems: 'center',
    marginBottom: 30,
  },
  logoCircle: {
    width: 66,
    height: 66,
    borderRadius: 22,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  logoSymbol: {
    color: '#fff',
    fontSize: 38,
    fontWeight: '900',
  },
  brand: {
    color: colors.dark,
    fontSize: 29,
    fontWeight: '900',
    letterSpacing: 2,
  },
  tagline: {
    color: colors.textSecondary,
    marginTop: 5,
    fontSize: 13,
  },
  card: {
    backgroundColor: colors.surface,
    padding: 22,
    borderRadius: radius.lg,
    elevation: 4,
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 4 },
  },
  eyebrow: {
    color: colors.lilac,
    fontSize: 11,
    fontWeight: '900',
    letterSpacing: 1.2,
  },
  title: {
    color: colors.dark,
    fontSize: 28,
    fontWeight: '900',
    marginTop: 9,
  },
  description: {
    color: colors.textSecondary,
    fontSize: 14,
    lineHeight: 21,
    marginTop: 8,
    marginBottom: 23,
  },
  input: {
    backgroundColor: colors.surfaceSoft,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    padding: 15,
    fontSize: 15,
    color: colors.text,
    marginBottom: 13,
  },
  errorBox: {
    backgroundColor: colors.dangerBackground,
    padding: 12,
    borderRadius: radius.sm,
    marginTop: 5,
  },
  errorText: {
    color: colors.danger,
    fontSize: 13,
    fontWeight: '600',
  },
  switchButton: {
    alignItems: 'center',
    paddingVertical: 17,
  },
  switchText: {
    color: colors.primary,
    fontWeight: '800',
    fontSize: 13,
  },
  footer: {
    textAlign: 'center',
    color: colors.textSecondary,
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 1,
    marginTop: 25,
  },
});
