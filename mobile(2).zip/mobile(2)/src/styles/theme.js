
export const colors = {
  primary: '#4c0661',
  dark: '#2f003d',
  lilac: '#9330b8',
  background: '#e3d8e8',
  surface: '#ffffff',
  surfaceSoft: '#f8f3fa',
  text: '#24142a',
  textSecondary: '#76677c',
  border: '#d8c9df',
  success: '#247a3d',
  successBackground: '#e3f5e7',
  danger: '#a52828',
  dangerBackground: '#ffe5e2',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 28,
};

export const radius = {
  sm: 8,
  md: 14,
  lg: 20,
  pill: 999,
};
