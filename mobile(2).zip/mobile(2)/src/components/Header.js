
import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { colors } from '../styles/theme';

export default function Header() {
  return (
    <View style={styles.header}>
      <Text style={styles.brand}>BUSCFÍSICA</Text>
      <Text style={styles.tagline}>
        Seu conhecimento em movimento
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    backgroundColor: colors.dark,
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 18,
    alignItems: 'center',
  },
  brand: {
    color: '#fff',
    fontSize: 25,
    fontWeight: '900',
    letterSpacing: 2,
  },
  tagline: {
    color: '#eadcf0',
    fontSize: 12,
    marginTop: 4,
  },
});
